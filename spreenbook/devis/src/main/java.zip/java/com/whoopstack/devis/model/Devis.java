package com.whoopstack.devis.model;

import java.util.Date;

public class Devis {
    private long id;
    private long Number;
    private 
}
