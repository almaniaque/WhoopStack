package com.whoopstack.devis.service;

import org.springframework.stereotype.Service;

@Service
public class DevisService {

}
