package com.whoopstack.devis.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.whoopstack.devis.model.Client;

@Service
public class ClientService {

    private final List<Client> clients = new ArrayList<>();
    private Long nextId = 1L;

    public List<Client> getAllClient() {
        return clients;
    }

    public Client getClientById(long id) {
        for (Client client : clients) {
            if (client.getId().equals(id)) {
                return client;
            }
        }
        return null;
    }

    public Client createClient(Client client) {
        client.setId(nextId);
        nextId++;

        clients.add(client);

        return client;

    }

    public void deleteClient(long id) {
        clients.removeIf(client -> client.getId().equals(id));
    }

}
